include_list = [
    "example",
    "config.py"
]
exclude_list = [
    "/Users/liukang/apache-maven-3.8.1/LICENSE",
    "/Users/liukang/apache-maven-3.8.1/lib",
    "/Users/liukang/anaconda3/envs",
    "/Users/liukang/anaconda3/lib",
    "/Users/liukang/anaconda3/include",
    "/Users/liukang/anaconda3/pkgs",
    ".DS_Store",
    ".gitignore"
]
cache_dir = "./cache/"
password = "123456"
